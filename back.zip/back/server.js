const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'sistreg'
});

db.connect((err) => {
  if (err) {
    console.error('Erro ao conectar no MySQL:', err);
    return;
  }
  console.log('Conectado ao MySQL');
});

app.get('/ping', (req, res) => {
  res.json({ message: 'API OK' });
});

app.get('/comandas', (req, res) => {
  const sql = 'SELECT * FROM comandas ORDER BY data_criacao DESC';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Erro ao buscar comandas:', err);
      return res.status(500).json({ error: 'Erro ao buscar comandas' });
    }
    res.json(results);
  });
});

app.post('/comandas', (req, res) => {
  const {
    numero_comanda,
    cliente,
    endereco,
    qtd_caixas,
    valor,
    forma_pagamento,
    pago,
    status_entrega
  } = req.body;

  const sql = `
    INSERT INTO comandas
    (numero_comanda, cliente, endereco, qtd_caixas, valor, forma_pagamento, pago, status_entrega)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(
    sql,
    [
      numero_comanda,
      cliente,
      endereco,
      qtd_caixas,
      valor,
      forma_pagamento,
      pago || 0,
      status_entrega || 'PENDENTE'
    ],
    (err, result) => {
      if (err) {
        console.error('Erro ao cadastrar comanda:', err);
        return res.status(500).json({ error: 'Erro ao cadastrar comanda' });
      }
      res.status(201).json({
        id: result.insertId,
        message: 'Comanda criada com sucesso'
      });
    }
  );
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
